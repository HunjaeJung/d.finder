//
//  UIViewController+BNCDebugging.h
//  Branch-TestBed
//
//  Created by Qinwei Gong on 11/12/14.
//  Copyright (c) 2014 Branch Metrics. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (BNCDebugging)
@end
