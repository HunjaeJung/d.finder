package io.branch.referral;

public interface NetworkCallback {
	public void finished(ServerResponse serverResponse);
}
