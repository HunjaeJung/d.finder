/** Automatically generated file. DO NOT MODIFY */
package io.branch.referral;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}